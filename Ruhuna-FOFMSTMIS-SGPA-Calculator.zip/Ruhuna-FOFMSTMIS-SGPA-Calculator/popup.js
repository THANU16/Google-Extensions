document.addEventListener("DOMContentLoaded", () => {
    const extensionName = document.getElementById("extensionName");
    extensionName.style.textAlign = "center";
});
